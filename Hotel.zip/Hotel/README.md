# SAM Hotel Reservation System

A comprehensive hotel reservation system built with Spring Boot, featuring package management, room booking, itinerary planning, transportation services, and customer support.

## 🏨 Features

### Core Functionality
- **Package Management**: Honeymoon, Business, Family packages with CRUD operations
- **Room Booking**: Room availability and booking management
- **Itinerary Management**: "Things to do" activities and tours
- **Transportation System**: Airport pickup, city tours, intercity travel
- **Offers Section**: Special discounts and promotional offers
- **Customer Support**: Comprehensive FAQ system

### User Management
- **Admin Panel**: Full CRUD operations for all entities
- **Customer Portal**: Booking and browsing interface
- **Authentication**: Role-based access control
- **Registration**: Customer self-registration

### Technical Features
- **Persistent Database**: H2 file database with data persistence
- **Responsive Design**: Mobile-friendly Bootstrap UI
- **Currency Support**: Sri Lankan Rupees (LKR)
- **Beautiful UI**: Modern design with sliding images

## 🚀 Quick Start

### Prerequisites
- Java 17 or higher
- Maven 3.6 or higher

### Running the Application

#### Option 1: Using Batch Files (Recommended)

**Starting the Application:**
1. **Start the application**: Double-click `start-hotel.bat` or `start-hotel-persistent.bat`
2. **Stop the application**: Double-click `stop-hotel.bat`

**If you get database lock errors:**
1. Run `force-unlock-database.bat` first
2. Then start the application normally

#### Option 2: Using Command Line
```bash
# Start the application (persistent database by default)
mvnw.cmd spring-boot:run

# Stop the application (Ctrl+C)
```

### Accessing the Application
- **Main Website**: http://localhost:8080
- **H2 Database Console**: http://localhost:8080/h2-console
  - JDBC URL: `jdbc:h2:file:./data/hoteldb`
  - Username: `sa`
  - Password: `password`

## 🔐 Default Credentials

### Admin Access
- **Username**: `admin`
- **Password**: `123`

### Customer Registration
- Customers can register through the registration page
- All new registrations are automatically assigned customer role

## 📊 Database Information

### Database Type
- **H2 File Database** (persistent storage)
- **Location**: `./data/hoteldb.mv.db`
- **Backup**: Copy the entire `data/` folder

### Database Features
- ✅ **Data Persistence**: Survives application restarts
- ✅ **Schema Evolution**: Automatic schema updates
- ✅ **Connection Management**: Robust connection handling
- ✅ **Lock Prevention**: AUTO_SERVER mode prevents file locks

### Sample Data
The application comes pre-loaded with:
- 1 Admin user
- 3 Hotel packages (Honeymoon, Business, Family)
- 3 Room types (Deluxe, Executive Suite, Family Room)
- 3 Activities (City Tour, Beach Relaxation, Cultural Heritage)
- 3 Transportation services
- 3 Special offers
- 4 FAQ entries

## 🛠️ Troubleshooting

### Database Lock Issues
If you encounter "Database may be already in use" errors:
1. Run `stop-hotel.bat` to properly stop the application
2. Wait a few seconds
3. Run `start-hotel.bat` to restart

### Port Already in Use
If port 8080 is already in use:
1. Stop any other applications using port 8080
2. Or change the port in `application.properties`:
   ```properties
   server.port=8081
   ```

### Data Issues
If you need to reset the database:
1. Stop the application
2. Delete the `data/` folder
3. Restart the application (sample data will be recreated)

## 📁 Project Structure

```
src/
├── main/
│   ├── java/com/example/
│   │   ├── controller/     # Web controllers
│   │   ├── model/         # Entity models
│   │   ├── repository/    # Data repositories
│   │   ├── service/       # Business logic
│   │   └── security/      # Security configuration
│   └── resources/
│       ├── templates/     # Thymeleaf templates
│       └── application.properties
├── data/                  # H2 database files
├── start-hotel.bat       # Start script
├── stop-hotel.bat        # Stop script
└── README.md             # This file
```

## 🎨 UI Features

### Home Page
- Hero section with sliding images
- Featured packages, rooms, and activities
- Special offers section
- Responsive navigation

### Admin Dashboard
- Statistics overview
- CRUD operations for all entities
- Modern sidebar navigation
- Quick action buttons

### Customer Dashboard
- Personalized welcome message
- Featured content browsing
- Quick access to all features
- Profile management

## 💰 Currency and Pricing

- **Currency**: Sri Lankan Rupees (LKR)
- **Format**: Rs. 25,000
- **All prices** displayed in LKR throughout the application

## 🔧 Development

### Adding New Features
1. Create entity models in `model/` package
2. Create repositories in `repository/` package
3. Create services in `service/` package
4. Create controllers in `controller/` package
5. Create Thymeleaf templates in `resources/templates/`

### Database Schema
The application uses JPA/Hibernate with automatic schema management:
- Tables are created automatically
- Schema updates are handled automatically
- Data persists between application restarts

## 📞 Support

For technical support or questions about the SAM Hotel Reservation System, please refer to the FAQ section in the application or contact the development team.

---

**SAM Hotel Reservation System** - Built with ❤️ using Spring Boot
